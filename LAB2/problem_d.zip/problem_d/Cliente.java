import java.util.Locale;
import java.util.Scanner;

/**
 * Represents the interface between the user and the program
 * 
 * @author Matheus Martins Oliveira | a85794
 * @version 1.0 | 27/02/2026
 */
public class Cliente {
    public static void main(String[] args) {
        Locale.setDefault(Locale.US);

        Scanner scanner = new Scanner(System.in);
        Ponto p = new Ponto(scanner.nextFloat(), scanner.nextFloat());
        Vetor v = new Vetor(scanner.nextFloat(), scanner.nextFloat());
        SegmentoReta sr = new SegmentoReta(p, v);
        System.out.println(sr.toString());
        scanner.close();
    }
}
