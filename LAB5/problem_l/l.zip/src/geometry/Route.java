package geometry;

import java.util.ArrayList;
import java.util.List;

import geometry.shapes.Shape;
import main.Helper;

/**
 * @author Matheus Martins Oliveira | a85794
 * @version 1.0 | 12/03/2026
 * @inv
 */
public class Route implements Shape {
    protected List<Point> points;
    protected List<SegmentoReta> segments = null;
    protected double length = 0;

    public Route(List<Point> points) {
        if (points.size() < 2)
            Helper.ivExit(ERR_MSG());

        this.points = points;
        this.length = genLength();
    }

    public Route(String[] data) {
        if (data.length % 2 != 0)
            Helper.ivExit(ERR_MSG());

        this.points = Helper.pointReader(data);
        this.length = genLength();
    }

    private double genLength() {
        double length = 0;
        for (int i = 0; i < this.points.size() - 1; i++) {
            length += points.get(i).distanceTo(points.get(i + 1));
        }

        return length;
    }

    public List<Point> points() {
        return this.points;
    }

    public List<SegmentoReta> segments() {
        if (this.segments == null)
            segments = genSegments();

        return this.segments;
    }

    public double length() {
        return length;
    }

    protected List<SegmentoReta> genSegments() {
        List<SegmentoReta> segments = new ArrayList<SegmentoReta>();
        for (int i = 0; i < this.points.size() - 1; i++) {
            try {
                segments.add(new SegmentoReta(this.points.get(i), this.points.get(i + 1)));
            } catch (Exception e) {
                Helper.ivExit(e.getMessage());
            }
        }

        return segments;
    }

    @Override
    public List<Point> intersect(SegmentoReta sr) {
        List<Point> intersections = new ArrayList<Point>();

        for (SegmentoReta segment : genSegments()) {
            Point intersection = segment.intersect(sr);
            if (intersection != null && !intersections.contains(intersection))
                intersections.add(intersection);
        }

        return intersections.isEmpty() ? null : intersections;
    }

    public List<Point> intersect(Shape shape) {
        List<Point> intersections = new ArrayList<Point>();
        for (SegmentoReta segment : genSegments()) {
            List<Point> intersectionsWithP = shape.intersect(segment);
            if (intersectionsWithP == null)
                continue;

            intersectionsWithP.sort(Point.compareToRef(segment.a()));
            for (Point intersection : intersectionsWithP) {
                intersections.add(intersection);
            }
        }

        return intersections.isEmpty() ? null : intersections;
    }

    @Override
    public String toString() {
        return Helper.pointsToString(this.points);
    }

    @Override
    public String ERR_MSG() {
        return "Rota:iv";
    }
}
