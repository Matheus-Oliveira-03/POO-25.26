package main;

import java.util.ArrayList;
import java.util.List;

import geometry.Point;
import geometry.Route;
import geometry.SegmentoReta;
import geometry.Vector;

/**
 * Represents the moviment of a plane within a certain trajectory. <br>
 * Since the tranjectory is defined by a line-segment, this class extends from
 * the class SegmentoReta.
 * 
 * @extends {@link SegmentoReta}
 * @author Matheus Martins Oliveira | a85794
 * @version 3.0 | 06/04/2026
 */
public class AutoPilot extends Route {
    private Vector windSpeed;
    private double linearSpeed;

    /**
     * Constructor from two points
     * 
     * @param start  an {@code Point} from which the plane will depart
     * @param finish The {@code Point} where the plane will arrive
     */
    public AutoPilot(List<Point> points, Vector w, double ls) {
        super(points);
        assignParameters(w, ls);
    }

    public AutoPilot(String[] data, Vector w, double ls) {
        super(data);
        assignParameters(w, ls);
    }

    private void assignParameters(Vector v, double d) {
        if (v == null || d == 0)
            Helper.ivExit(ERR_MSG());

        this.windSpeed = v;
        this.linearSpeed = d;
    }

    /**
     * @param linearSpeed an {@code double} representing the linear speed of the
     *                    plane
     * @return a double representing the time needed to fly through the trajectory,
     *         in seconds
     */
    public double time(SegmentoReta sr) {
        if (sr == null)
            Helper.ivExit(ERR_MSG());

        double r = sr.a().distanceTo(sr.b());
        return r / linearSpeed;
    }

    public double time() {
        List<SegmentoReta> _segments = this.segments();
        double totalTime = 0;

        for (SegmentoReta sr : _segments) {
            totalTime += this.time(sr);
        }

        return totalTime;
    }

    /**
     * @param windSpeed an {@code Vetor} representing the wind speed
     * @param time      an {@code double} representing the time in which the
     *                  trajectory will be covered
     * @return a {@code Vetor} representing the plane's speed
     */
    public Vector speed(SegmentoReta sr) {
        if (sr == null)
            Helper.ivExit(ERR_MSG());

        return (sr.directionVector().mult(1 / this.time(sr))).sub(this.windSpeed);
    }

    public List<Vector> speed() {
        List<SegmentoReta> _segments = this.segments();
        List<Vector> speeds = new ArrayList<>();

        for (SegmentoReta sr : _segments) {
            speeds.add(this.speed(sr));
        }

        return speeds;
    }

    public Point position(double time) {
        List<SegmentoReta> _segments = this.segments();
        double currentTime = 0;
        double oldTime = 0;

        for (SegmentoReta sr : _segments) {
            oldTime = currentTime;
            double segmentTime = this.time(sr);
            currentTime += segmentTime;

            if (time <= currentTime) {
                double t = (time - oldTime) / segmentTime;
                return sr.getPoint(t);
            }
        }

        return null;
    }
}
